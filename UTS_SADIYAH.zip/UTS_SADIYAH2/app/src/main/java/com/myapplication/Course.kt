package com.myapplication

data class Course(
    val title:String,
    val path:String,
    val image:String
)



